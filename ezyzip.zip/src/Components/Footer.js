import React from 'react';
import './Footer.css'; 

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-links">
          <ul>
            <li><a href="/contact-us">Contact Us</a></li>
            <li><a href="/terms-conditions">Terms & Conditions</a></li>
            <li><a href="/privacy-policy">Privacy Policy</a></li>
            <li><a href="/copyright-policy">Copyright Policy</a></li>
            <li><a href="/hyperlink-policy">Hyperlink Policy</a></li>
            <li><a href="/accessibility-statement">Accessibility Statement</a></li>
            <li><a href="/website-policy">Website Policy</a></li>
            <li><a href="/help">Help</a></li>
            <li><a href="/stqc-certificate">STQC Certificate</a></li>
            <li><a href="/rti-audit">RTI Third Party Audit</a></li>
            <li><a href="/public-grievances">Public Grievances</a></li>
            <li><a href="/web-information-manager">Web Information Manager</a></li>
            <li><a href="/archives">Archives</a></li>
          </ul>
        </div>
        <div className="footer-info">
          <p>Last Updated: 09/08/2024</p>
          <p>Visitors: 27,094,588</p>
          <p>Copyright © 2024, DRDO, Ministry of Defence, Government of India</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
