import React, { useState, useEffect } from "react";
import "./Login.css";
import axios from 'axios';

import bg1 from "../Components/bg1.jpg";
import bg2 from "../Components/bg2.jpg";
import bg3 from "../Components/bg3.jpg";
import Services from "./Services";


const Signup = () => {
  const [backgroundIndex, setBackgroundIndex] = useState(0);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [authenticated, setAuthenticated] = useState(false);
  

  const backgrounds = [bg1, bg2, bg3];

  useEffect(() => {
    const interval = setInterval(() => {
      setBackgroundIndex((prevIndex) => (prevIndex + 1) % backgrounds.length);
    }, 1000);

    return () => clearInterval(interval);
  }, [backgrounds.length]);

  const handleLeftArrowClick = () => {
    setBackgroundIndex(
      (prevIndex) => (prevIndex - 1 + backgrounds.length) % backgrounds.length
    );
  };

  const handleRightArrowClick = () => {
    setBackgroundIndex((prevIndex) => (prevIndex + 1) % backgrounds.length);
  };

  const handleSubmit =async (event) => {
    event.preventDefault();
    try {
      const response = await axios.post('http://localhost:3001/register', {name, email, password });
      localStorage.setItem('token', response.data.token);
      alert('Registered successfully');
      setAuthenticated(true)

    } catch (error) {
     
      alert('Error in');
      
    }
  };
  

  if (authenticated){
    return <Services />;
  }
  

  

 
  return (
    <div
      className="login-container"
      style={{ backgroundImage: `url(${backgrounds[backgroundIndex]})` }}
    >
    
      <div className="arrow left-arrow" onClick={handleLeftArrowClick}>
        &#8249;
      </div>

   
      <form onSubmit={handleSubmit}>
        <h2>Signup</h2>
        <div className="label-input-container" style={{ marginLeft: "22px" }}>
          <label htmlFor="email">Name :</label>
          <input
            type="text"
            id="name"
            name="name"
            placeholder="Enter your name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>


        <div className="label-input-container" style={{ marginLeft: "22px" }}>
          <label htmlFor="email">Email :</label>
          <input
            type="email"
            id="email"
            name="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div className="label-input-container">
          <label htmlFor="password">Password :</label>
          <input
            type="password"
            id="password"
            name="password"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <button type="submit">Signup</button>
      </form>


      <div className="arrow right-arrow" onClick={handleRightArrowClick}>
        &#8250;
      </div>
    </div>
  );
};

export default Signup;
