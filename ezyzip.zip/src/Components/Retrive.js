import React, { useState, useEffect } from 'react';
import axios from 'axios';

const PdfList = () => {
  const [files, setFiles] = useState([]);

  useEffect(() => {
    // Fetch list of PDF files
    const fetchFiles = async () => {
      try {
        const response = await axios.get('http://localhost:3001/files');
        setFiles(response.data);
      } catch (error) {
        console.error('Error fetching files:', error);
      }
    };

    fetchFiles();
  }, []);

  return (
    <div>
      <h2>Uploaded Documents</h2>
      <div className="pdf-container" style={{display:"flex", textAlign:'center', justifyContent:"space-around", height:"70vh",  padding:"10px 10px"}}>
        {files.length > 0 ? (
          files.map((file, index) => (
            <div key={index} className="pdf-item" style={{height:"10%", width:"20%", color:'white', margin:"10px 20px", borderRadius:"50px"}}>
              <a href={`http://localhost:3001/files/${file}`} target="_blank" rel="noopener noreferrer" style={{textDecoration:"none", color:'black', fontSize:"24px",textAlign:"center",marginTop:"40px"}}>
                {file}
              </a>
            </div>
            
          ))
        ) : (
          <p>No PDF files available.</p>
        )}
        
      </div>
      <h3><a href='/services' style={{marginBottom:"500px"}}>Back to Services</a></h3>
    </div>
  );
};

export default PdfList;
