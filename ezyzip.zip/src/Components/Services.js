import React from "react";
import "./Services.css";
import { Link } from "react-router-dom";

const Services = () => {
  return (
    <div className="services-container">
      <div className="services-header">
        <h1>Services</h1>
      </div>
      <div className="services-content">
        <div className="service-box">
          <Link to="/monitoring">Monitoring</Link>
        </div>
        <div className="service-box">
          <Link to="/Insert">Insert Document</Link>
        </div>
        <div className="service-box">
          <Link to="/retrive">Retrieve Document</Link>
        </div>
      </div>
    </div>
  );
};

export default Services;
