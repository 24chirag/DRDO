

import React from "react";
import "./Header.css"; 
import drdoLogo from "./drdologo.png";

const Header = () => {
  return (
    <header className="drdo-header">
      <div className="header-top">
        <div className="logo">
          <img src={drdoLogo} alt="DRDO Logo" />
        </div>
        <div className="search-bar">
          <input type="text" placeholder="Search" />
        </div>
      </div>

      <hr className="nav-line"></hr>

      <nav className="nav-links">
        <ul>
          <li>
            <a href="https://www.drdo.gov.in/drdo/">Home</a>
          </li>
          <li>
            <a href="/signup">Signup</a>
          </li>
          <li>
            <a href="https://www.drdo.gov.in/drdo/orgchart">Organisation</a>
          </li>
          <li>
            <a href="https://www.drdo.gov.in/drdo/systems-and-subsystems-industry-design-development-and-manufacture">
              Outreach
            </a>
          </li>
          <li>
            <a href="https://www.drdo.gov.in/drdo/careers">Careers</a>
          </li>
          <li>
            <a href="https://www.drdo.gov.in/drdo/publications">Publications</a>
          </li>
          <li>
            <a href="https://www.drdo.gov.in/drdo/rti-cell/home">RTI</a>
          </li>
          <li>
            <a href="https://www.drdo.gov.in/drdo/rti-cell/contact-us">
              Contact
            </a>
          </li>
          
        </ul>
      </nav>
    
    </header>
  );
};

export default Header;
