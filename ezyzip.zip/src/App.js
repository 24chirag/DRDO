import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Header from "./Components/Header";
import Login from "./Components/Login";
import Footer from "./Components/Footer";
import "./App.css";
import Signup from "./Components/Signup";
import Insert from "./Components/Insert";
import PdfList from "./Components/Retrive";
import Services from "./Components/Services";

function App() {
  return (
    <Router>
      <div className="App">
        <Header />
        <Routes>
          <Route exact path="/" element={<Login/>} />
          <Route exact path="/signup" element={<Signup/>} />
          <Route exact path="/Insert" element={<Insert/>} />
          <Route exact path="/retrive" element={<PdfList/>} />
          <Route exact path="/services" element={<Services/>} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
