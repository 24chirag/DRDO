const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const multer = require('multer');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.json())
app.use(express.urlencoded({extended:true}))

const path = require('path');
const fs = require('fs');




// Configure multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // Set the destination directory for uploaded files
    const uploadPath = path.join(__dirname, 'uploads');
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    // Set the file name for the uploaded file
    cb(null, file.originalname);
  },
});

// Initialize multer with the defined storage
const upload = multer({ storage });

// Serve static files from 'uploads' directory
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.post('/upload', upload.single('file'), (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    res.status(200).json({ file: req.file.filename });
  });
  
  // Endpoint to list files
  app.get('/files', (req, res) => {
    const uploadPath = path.join(__dirname, 'uploads');
    fs.readdir(uploadPath, (err, files) => {
      if (err) {
        return res.status(500).json({ error: 'Failed to list files' });
      }
      res.json(files);
    });
  });
  
  // Serve files
  app.use('/files', express.static(path.join(__dirname, 'uploads')));


// Endpoint to retrieve the uploaded PDF file
app.get('/files/:filename', (req, res) => {
  const filePath = path.join(__dirname, 'uploads', req.params.filename);
  if (fs.existsSync(filePath)) {
    res.sendFile(filePath);
  } else {
    res.status(404).json({ error: 'File not found' });
  }
});


// Connect to MongoDB
mongoose.connect('mongodb+srv://chiragansharma24:koko123@jobsearch.rzgluea.mongodb.net/', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Define User Schema and Model
const userSchema = new mongoose.Schema({
  name:String,
  email: String,
  password: String,
});

const User = mongoose.model('User', userSchema);

app.get("/",(req,res)=>{
    res.send("helloo world")
})

// Register Route
app.post('/register', async (req, res) => {
  const { name,email, password } = req.body; 
  console.log(name + email + password)
  const hashedPassword = await bcrypt.hash(password, 10);
  const user = new User({ name,email, password: hashedPassword });
  await user.save();
  res.status(201).send('User registered');
});

// Login Route
app.post('/login', async (req, res) => {
  const { email, password } = req.body;
 
  const user = await User.findOne({ email });
  if (!user) return res.status(400).send('User not found');
  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) return res.status(400).send('Invalid credentials');
  const token = jwt.sign({ id: user._id }, 'secretkey', { expiresIn: '1h' });
  res.json({ token });
});
app.post('/logout',async (req,res)=>{
    const token = " "
    res.json({token});
})
app.listen(3001, () => console.log('Server running on port 3000'));
